# AluraFlix
Página de catálogo de vídeos desenvolvido na unidade "Página Web: criando um catálogo de vídeos com HTML e CSS" da Alura Start.

## Tecnologias utilizadas
- HTML
- CSS

## Acessando o código
Para acessar o código referente às aulas, clique no seletor `main` do repositório e selecione a aula desejada.

## Notas e créditos
Feito por Guilherme Silveira, instrutor e fundador da Alura.
